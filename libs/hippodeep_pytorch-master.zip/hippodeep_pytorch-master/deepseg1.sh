python $(dirname $0)/model_apply_head_and_hippo.py $@
